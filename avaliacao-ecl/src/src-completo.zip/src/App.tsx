import React, { useState, useCallback, useEffect } from 'react';
import { inicializarCompat } from './compatECL';
import { loadLibrary } from './libraryService';
import { Perfil, Aluno, PlanoAula as TPlanoAula } from './types';
import { Login } from './components/Login';
import { ManualCozinheiro } from './components/ManualCozinheiro';
import { ManuaisAluno } from './components/ManuaisAluno';
import { Header, LayoutProfessor, VistaProf } from './components/Header';
import { PainelProfessor } from './components/PainelProfessor';
import { CalendarioMensal } from './components/PlanoAula';
import { EstadoSincronizacao } from './components/EstadoSincronizacao';
import { modulosAtivos } from './cronograma';
import ProfessorView from './components/ProfessorView';
import { AlunoView } from './components/AlunoView';
import { ValidacaoView } from './components/ValidacaoView';
import { CoordenadoraView } from './components/CoordenadoraView';
import PlanoAula from './components/PlanoAula';
import { ModalFullscreen } from './components/ModalFullscreen';
import { VistaDePlano } from './components/VistaDePlano';
import { MenuDoPlano } from './components/MenuDoPlano';
import { ManualProfessor } from './components/ManualProfessor';
import { posicaoNaUC, totalAulasUC, avisoFimUC } from './rotuloPlano';
import { CRONOGRAMA_2026_2027 } from './cronograma';
import { AvaliacaoPorUC } from './components/AvaliacaoPorUC';
import { MomentosAvaliacao } from './components/MomentosAvaliacao';
import Requisicao from './components/Requisicao';

// Wrapper Orçamentos — fichas e requisições sem plano
function OrcamentosView({ turmaId, nomeProfessor, onAlteracao, onGuardado }: {
  turmaId: string; nomeProfessor: string;
  onAlteracao: () => void; onGuardado: () => void;
}) {
  const [tab, setTab] = React.useState<'fichas' | 'requisicoes'>('fichas');
  return (
    <div>
      <div style={{ background: '#fff7ed', borderRadius: 14, padding: '14px 16px',
        marginBottom: 14, border: '1.5px solid #fcd34d' }}>
        <div style={{ fontWeight: 700, fontSize: 15, color: '#92400e', marginBottom: 4 }}>💰 Orçamentos</div>
        <div style={{ fontSize: 13.5, color: '#78350f', lineHeight: 1.55 }}>
          Para calcular custos sem estar preso a uma aula: um evento, um
          almoço pedagógico, uma encomenda.
          <br />
          Nas requisições, escolhe <strong>Biblioteca</strong> para usar
          fichas técnicas que já tenhas feito.
        </div>
      </div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
        {([
          { id: 'fichas',      label: '📄 Fichas Técnicas' },
          { id: 'requisicoes', label: '🛒 Requisições' },
        ] as const).map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            style={{ flex: 1, padding: '10px', borderRadius: 10, border: 'none', cursor: 'pointer',
              fontSize: 13, fontWeight: tab === t.id ? 700 : 400,
              background: tab === t.id ? '#b5651d' : 'rgba(26,23,20,0.06)',
              color: tab === t.id ? '#fff' : 'rgba(26,23,20,0.6)' }}>
            {t.label}
          </button>
        ))}
      </div>
      {tab === 'fichas' && (
        <ProfessorView turmaId={turmaId} nomeProfessor={nomeProfessor}
          onAlteracao={onAlteracao} onGuardado={onGuardado} />
      )}
      {tab === 'requisicoes' && (
        <Requisicao nomeProfessor={nomeProfessor} turmaId={turmaId} />
      )}
    </div>
  );
}
import { FichaRegistoUC } from './components/FichaRegistoUC';

// Wrapper que combina Historial + Momentos + Ficha de Registo
function HistorialView({ turmaId, onIrPara }: {
  turmaId: string;
  onIrPara?: (vista: VistaProf, planoId?: string) => void;
}) {
  // "Por unidade" é o primeiro separador: é assim que o professor
  // pensa no percurso, e é onde vê o que ficou por avaliar.
  const [tab, setTab] = React.useState<'porUC' | 'historial' | 'momentos' | 'ficha'>('porUC');
  return (
    <div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 14, flexWrap: 'wrap' }}>
        {([
          { id: 'porUC',     label: '📚 Por unidade' },
          { id: 'historial', label: '📊 Historial' },
          { id: 'momentos',  label: '📐 Momentos' },
          { id: 'ficha',     label: '📋 Ficha de Registo' },
        ] as const).map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            style={{ flex: 1, padding: '10px 6px', borderRadius: 10, border: 'none', cursor: 'pointer',
              fontSize: 12, fontWeight: tab === t.id ? 700 : 400, minWidth: 80,
              background: tab === t.id ? '#b5651d' : 'rgba(26,23,20,0.06)',
              color: tab === t.id ? '#fff' : 'rgba(26,23,20,0.6)' }}>
            {t.label}
          </button>
        ))}
      </div>
      {tab === 'porUC' && (
        <HistorialPorUC
          turmaId={turmaId}
          onAbrirPlano={(planoId) => onIrPara?.('planos', planoId)}
          onValidar={(planoId) => onIrPara?.('validacao', planoId)}
        />
      )}
      {tab === 'historial' && <AvaliacaoPorUC turmaId={turmaId} />}
      {tab === 'momentos'  && <MomentosAvaliacao turmaId={turmaId} />}
      {tab === 'ficha'     && <FichaRegistoUC turmaId={turmaId} />}
    </div>
  );
}
import { CopiaSegurancaView } from './components/CopiaSeguranca';
import { GestaoRecuperacoes } from './components/GestaoRecuperacoes';
import { MapaCompetencias } from './components/MapaCompetencias';
import { CentroAvisos } from './components/CentroAvisos';
import { ErrorBoundary } from './components/ErrorBoundary';
import { EventosWizard } from './components/EventosWizard';
import { CronogramaTab } from './components/CronogramaTab';
import { HistorialPorUC } from './components/HistorialPorUC';
import { ArranqueAnoLetivo } from './components/ArranqueAnoLetivo';
import { sincronizarDoSheets, getEstadoSync, addAluno, seedHistorialTeste, seedPlanoTeste, getTurmas, seedAlunosReais,
  migrarTurmaAntiga,
  getPlanosAulaPorTurma, getSelecoes, getValidacoes,
  getFichasProducao, getRequisicaoPorPlano, getSessaoAula,
  estadoDaTurmaNaAula, addOrUpdatePlanoAula,
  autoavaliacoesPorValidar, getPlanosAula, publicarNoClassroom, requisicaoDesatualizada, publicarPlanoParaAlunos } from './backend';

function ModalGuardar({ mensagem, onGuardar, onDescartar, onCancelar }: {
  mensagem: string; onGuardar: () => void; onDescartar: () => void; onCancelar: () => void;
}) {
  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(26,23,20,0.6)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:9999, padding:20 }}>
      <div style={{ background:'#fff', borderRadius:16, padding:24, maxWidth:340, width:'100%', boxShadow:'0 20px 60px rgba(0,0,0,0.3)' }}>
        <div style={{ fontSize:32, textAlign:'center', marginBottom:12 }}>⚠️</div>
        <div style={{ fontWeight:700, fontSize:16, textAlign:'center', marginBottom:8 }}>Tens alterações por guardar</div>
        <div style={{ fontSize:13, color:'rgba(26,23,20,0.6)', textAlign:'center', marginBottom:20 }}>{mensagem}</div>
        <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
          <button onClick={onGuardar} style={{ padding:'12px', borderRadius:10, border:'none', background:'var(--sage)', color:'white', fontWeight:700, fontSize:14, cursor:'pointer' }}>✓ Guardar antes de sair</button>
          <button onClick={onDescartar} style={{ padding:'10px', borderRadius:10, border:'1px solid var(--border)', background:'#fff', color:'var(--danger)', fontWeight:600, fontSize:13, cursor:'pointer' }}>Descartar alterações</button>
          <button onClick={onCancelar} style={{ padding:'10px', borderRadius:10, border:'none', background:'transparent', color:'rgba(26,23,20,0.5)', fontSize:13, cursor:'pointer' }}>Cancelar — ficar aqui</button>
        </div>
      </div>
    </div>
  );
}

function AppInterno() {
  const [perfil, setPerfil] = useState<Perfil | null>(null);
  const [aluno, setAluno] = useState<Aluno | null>(null);
  // Arrancava com '1º ACP', a turma antiga — que já não existe.
  const [turmaId, setTurmaId] = useState<string>(() => getTurmas()[0]?.id || '1º BCR');
  const [nomeProfessor, setNomeProfessor] = useState<string>('');
  const [planoAberto, setPlanoAberto] = useState<TPlanoAula | null>(null);
  /** Onde o professor está dentro do plano — para o menu se marcar. */
  const [moduloPlano, setModuloPlano] = useState<string>('inicio');
  /** O menu pede para ir a um sítio; a vista obedece e limpa o pedido. */
  const [moduloPedido, setModuloPedido] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [planoEmPausa, setPlanoEmPausa] = useState<TPlanoAula | null>(null);
  // 'inicio' é o painel de blocos; os outros valores são os destinos.
  const [vistaGlobal, setVistaGlobal] = useState<VistaProf>('inicio');
  const [planoIdAlvo, setPlanoIdAlvo] = useState<string | null>(null);
  const [temAlteracoes, setTemAlteracoes] = useState(false);
  const [acaoPendente, setAcaoPendente] = useState<(() => void) | null>(null);
  const [guardarCallback, setGuardarCallback] = useState<(() => void) | null>(null);
  const [modalAberto, setModalAberto] = useState(false);
  const [modalMensagem, setModalMensagem] = useState('');
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'ok' | 'offline'>('idle');

  function atualizarDados() {
    if (!turmaId) return;
    setSyncStatus('syncing');
    sincronizarDoSheets(turmaId)
      .then(() => { setSyncStatus('ok'); setRefreshKey(k => k + 1); })
      .catch(() => setSyncStatus('offline'));
  }

  useEffect(() => {
    // Carregar biblioteca pedagógica V10 e inicializar compatECL
    loadLibrary()
      .then(() => {
        inicializarCompat();
        console.log('[App] Biblioteca V10 carregada.');
      })
      .catch(e => console.error('[App] Erro ao carregar biblioteca:', e));
    getTurmas();
    // Sincronizar dados do Sheets ao arrancar — garante dados actualizados em qualquer dispositivo
    sincronizarDoSheets(turmaId).catch(e => console.warn('[App] Sync inicial falhou:', e));
    migrarTurmaAntiga(false);   // planos com a turma antiga passam para a nova
    seedAlunosReais();          // acerta a lista de alunos com a oficial
    // seedAlunosTeste/seedHistorialTeste/seedPlanoTeste removidos — não injectar dados de teste em produção
  }, []);

  useEffect(() => {
    if (perfil === 'professor' && turmaId) {
      // O professor tem a versão mais recente dos planos: é daqui que o
      // Sheets recebe a turma nova, para os tablets dos alunos os verem.
      migrarTurmaAntiga(true);
      const { temSheets } = getEstadoSync();
      if (temSheets) atualizarDados();
    }
  }, [perfil, turmaId]);

  const registarAlteracao = useCallback((guardar?: () => void) => {
    setTemAlteracoes(true);
    if (guardar) setGuardarCallback(() => guardar);
  }, []);

  const limparAlteracoes = useCallback(() => {
    setTemAlteracoes(false);
    setGuardarCallback(null);
  }, []);

  function navegarCom(acao: () => void, mensagem?: string) {
    if (temAlteracoes) {
      setAcaoPendente(() => acao);
      setModalMensagem(mensagem || 'Se saíres agora perdes o que estás a preencher.');
      setModalAberto(true);
    } else {
      acao();
    }
  }

  function abrirPlano(plano: TPlanoAula) {
    navegarCom(() => { setPlanoAberto(plano); setPlanoEmPausa(null); limparAlteracoes(); });
  }

  function fecharPlano() {
    navegarCom(() => { setPlanoAberto(null); setPlanoEmPausa(null); limparAlteracoes(); setVistaGlobal('planos'); });
  }

  function irPara(vista: VistaProf) {
    if (vista === vistaGlobal && !planoAberto) return;
    navegarCom(() => {
      if (planoAberto) setPlanoEmPausa(planoAberto);
      setPlanoAberto(null);
      limparAlteracoes();
      setVistaGlobal(vista);
    });
  }

  function handleLogin(perfilRecebido: Perfil, alunoId?: string, turmaIdRecebida?: string, nomeUser?: string) {
    setPerfil(perfilRecebido);
    if (turmaIdRecebida) {
      setTurmaId(turmaIdRecebida);
      // Sincronizar dados desta turma ao fazer login
      sincronizarDoSheets(turmaIdRecebida).catch(() => {});
    }
    if (nomeUser) setNomeProfessor(nomeUser);
    if (perfilRecebido === 'aluno' && alunoId) {
      const partes = alunoId.split('-');
      const numero = parseInt(partes[partes.length - 1], 10) || 0;
      const tId = turmaIdRecebida || turmaId || '1º ACP';
      // Derivar ano do turmaId — '1º ACP' → 1, '2º ACP' → 2, '3º ACP' → 3
      const anoMatch = tId.match(/[123]/);
      const ano = anoMatch ? (parseInt(anoMatch[0]) as 1|2|3) : 1;
      const novoAluno: Aluno = { id: alunoId, turmaId: tId, numero, ano };
      setAluno(novoAluno);
      addAluno(novoAluno);
    }
  }

  function sair() {
    navegarCom(() => {
      setPerfil(null); setAluno(null); setNomeProfessor('');
      setPlanoAberto(null); setVistaGlobal('planos'); limparAlteracoes();
    }, 'Se saíres agora perdes o que estás a preencher.');
  }

  if (!perfil) return <Login onLogin={handleLogin} />;

  // ── Vista Professor ──────────────────────────────────────────────────────
  if (perfil === 'professor') {
    return (
      <LayoutProfessor
        vistaAtiva={vistaGlobal}
        onNavegar={irPara}
        nomeProfessor={nomeProfessor}
        turmaId={turmaId}
        onSair={sair}
        syncStatus={syncStatus}
        onAtualizar={atualizarDados}
        contextoPainel={{
          turmaId,
          nomeProfessor,
          plano: planoAberto || undefined,
          ucId: planoAberto?.ucId,
        }}
      >
        {modalAberto && (
          <ModalGuardar mensagem={modalMensagem}
            onGuardar={() => { setModalAberto(false); if (guardarCallback) guardarCallback(); limparAlteracoes(); if (acaoPendente) acaoPendente(); setAcaoPendente(null); }}
            onDescartar={() => { setModalAberto(false); limparAlteracoes(); if (acaoPendente) acaoPendente(); setAcaoPendente(null); }}
            onCancelar={() => { setModalAberto(false); setAcaoPendente(null); }}
          />
        )}

        {/* Plano em pausa */}
        {planoEmPausa && !planoAberto && (
          <div style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 14px', background:'#fef3c7', borderRadius:10, marginBottom:12, border:'1px solid #fcd34d' }}>
            <span style={{ fontSize:13, color:'#92400e', flex:1 }}>
              📋 Tens o plano "{planoEmPausa.titulo}" em pausa
            </span>
            <button onClick={() => setPlanoAberto(planoEmPausa)}
              style={{ fontSize:12, padding:'5px 12px', borderRadius:8, border:'none', background:'#f59e0b', color:'white', fontWeight:600, cursor:'pointer' }}>
              ← Voltar ao plano
            </button>
          </div>
        )}

        {/* Conteúdo da vista activa — o plano aberto passa a mostrar-se
            num modal quase-fullscreen por cima do calendário, em vez de
            substituir o ecrã todo. O calendário/lista continua por trás. */}
        {planoAberto && (() => {
          // Tudo o que o menu do plano precisa de saber. Lido aqui, não
          // calculado de novo: são as mesmas funções que o resto usa.
          const fichasDoPlano = getFichasProducao()
            .filter((f: any) => (planoAberto.fichasIds || []).includes(f.id));
          const req = getRequisicaoPorPlano(planoAberto.id);

          // "Plano 3 de 5" — vem das MESMAS funções que o resto da
          // aplicação usa. Eu estava a contar os planos já criados e o
          // rotuloPlano conta as semanas do cronograma: dois números
          // diferentes a dizer a mesma coisa no mesmo ecrã.
          const posicao = posicaoNaUC(planoAberto);
          const totalDaUC = totalAulasUC(planoAberto);

          const sessao = getSessaoAula(planoAberto.id);
          const alunosNaAula = sessao?.abertaEm
            ? (() => {
                const est = estadoDaTurmaNaAula(planoAberto.id, turmaId);
                return `${est.filter((e: any) => e.entrou).length}/${est.length}`;
              })()
            : undefined;

          return (
            <ModalFullscreen
              titulo={planoAberto.titulo || 'Plano de Aula'}
              subtitulo={turmaId}
              onFechar={fecharPlano}
              temAlteracoes={temAlteracoes}
              aoGuardar={guardarCallback || undefined}
              menuLateral={
                <MenuDoPlano
                  plano={planoAberto}
                  fichas={fichasDoPlano}
                  temRequisicao={!!req}
                  numeroRequisicao={(req as any)?.numero}
                  totalCompetencias={(planoAberto as any).competenciasIds?.length
                    || (planoAberto as any).compAdicionadas?.length || 0}
                  posicao={posicao > 0 ? posicao : undefined}
                  totalPlanos={totalDaUC || undefined}
                  moduloActivo={moduloPlano as any}
                  aoIrPara={(m) => setModuloPedido(m)}
                  aoSair={fecharPlano}
                  alunosNaAula={alunosNaAula}
                  aviso={avisoFimUC(planoAberto) || undefined}
                  requisicaoDesatualizada={!!requisicaoDesatualizada(planoAberto.id)}
                  disciplina={(() => {
                    const m = CRONOGRAMA_2026_2027.find((x: any) => x.id === planoAberto.ucId);
                    return (m as any)?.disciplina;
                  })()}
                  porValidar={(() => {
                    const vals = new Set(getValidacoes().map((v: any) => v.selecaoId));
                    return getSelecoes().filter((s: any) =>
                      s.planoAulaId === planoAberto.id && !vals.has(s.id)).length;
                  })()}
                  aoPublicar={planoAberto.estado !== 'publicado' ? () => {
                    const p = { ...planoAberto, estado: 'publicado' as const,
                      atualizadoEm: new Date().toISOString() };
                    setPlanoAberto(p);
                    // Publica e vai confirmar ao Sheets — é de lá que o
                    // aluno lê. Sem confirmação, a aula podia nunca chegar.
                    publicarPlanoParaAlunos(planoAberto.id).then(r => {
                      if (r.ok) alert('Publicado. Os alunos já veem esta aula.');
                      else alert('Atenção: ' + r.erro);
                    });

                    // O Classroom só agora faz sentido: o plano está
                    // pronto, com as fichas e o guião que tiver. Antes
                    // perguntava-se ao criar o plano, ainda vazio.
                    if (window.confirm(
                      'Plano publicado para os alunos.\n\n'
                      + 'Publicar também no Google Classroom?'
                    )) {
                      const fichas = getFichasProducao()
                        .filter((f: any) => (p.fichasIds || []).includes(f.id));
                      publicarNoClassroom('plano', turmaId, {
                        titulo: p.titulo, data: p.data,
                        horaInicio: p.horaInicio, horaFim: p.horaFim,
                        ucId: p.ucId, ucNome: p.ucNome,
                        pratos: fichas.map((f: any) => f.nomePrato).filter(Boolean),
                        observacoes: (p as any).observacoes || '',
                      }).then(res => {
                        if (res.ok) alert('Publicado no Classroom.');
                        else alert('Não foi possível publicar no Classroom: ' + (res.erro || 'erro desconhecido'));
                      });
                    }
                  } : undefined}
                />
              }
            >
              <VistaDePlano
                key={refreshKey}
                plano={planoAberto}
                turmaId={turmaId}
                nomeProfessor={nomeProfessor}
                onVoltar={fecharPlano}
                onPlanoActualizado={(p: any) => setPlanoAberto(p)}
                onAlteracao={registarAlteracao}
                onGuardado={limparAlteracoes}
                aoMudarModulo={(m) => { setModuloPlano(m); setModuloPedido(null); }}
                moduloPedido={moduloPedido}
              />
            </ModalFullscreen>
          );
        })()}
        <>
          {vistaGlobal === 'inicio' && (() => {
            // A unidade em curso sai do cronograma, pela data de hoje —
            // o professor não tem de a procurar.
            const hojeISO = new Date().toISOString().slice(0, 10);
            const ativos = modulosAtivos(turmaId, hojeISO);
            const emCurso = [...ativos].sort((a, b) => a.dataFim.localeCompare(b.dataFim))[0];
            const planos = getPlanosAulaPorTurma(turmaId);
            return (
              <>
              {/* O que ainda não chegou ao Sheets. Fica no topo do painel,
                  onde o professor passa sempre — antes só se descobria
                  quando o trabalho já estava perdido. */}
              <div style={{ maxWidth: 820, margin: '0 auto 4px' }}>
                <EstadoSincronizacao turmaId={turmaId} />
              </div>

              {/* Autoavaliações por validar, de qualquer plano. Sem isto
                  o professor passava para a aula seguinte sem dar por
                  elas — e sem validação não contam para nada. */}
              {(() => {
                const pendentes = autoavaliacoesPorValidar(turmaId);
                if (!pendentes.length) return null;
                const total = pendentes.reduce((s, p) => s + p.quantos, 0);
                return (
                  <div style={{ maxWidth: 820, margin: '0 auto 12px',
                    background: '#FFF4DC', border: '1.5px solid #F6A623',
                    borderRadius: 12, padding: '14px 16px' }}>
                    <div style={{ fontSize: 15, fontWeight: 700, color: '#7a4f00' }}>
                      {total} autoavaliaç{total === 1 ? 'ão' : 'ões'} por validar
                    </div>
                    <div style={{ fontSize: 13.5, color: 'rgba(26,23,20,0.65)',
                      marginTop: 4, lineHeight: 1.55 }}>
                      Enquanto não validares, não contam para a nota nem para
                      o percurso do aluno.
                    </div>
                    <div style={{ marginTop: 10, display: 'flex', gap: 7,
                      flexWrap: 'wrap' }}>
                      {pendentes.slice(0, 4).map(p => (
                        <button key={p.planoAulaId}
                          onClick={() => {
                            const plano = getPlanosAula().find((x: any) => x.id === p.planoAulaId);
                            if (plano) { setPlanoAberto(plano as any); setModuloPedido('turma'); }
                          }}
                          style={{ padding: '8px 13px', borderRadius: 9,
                            border: '1px solid #F6A623', background: '#fff',
                            color: '#7a4f00', fontSize: 13, fontWeight: 700,
                            cursor: 'pointer', fontFamily: 'inherit' }}>
                          {p.data ? new Date(p.data + 'T00:00:00').toLocaleDateString('pt-PT', { day: 'numeric', month: 'short' }) : 'Plano'}
                          {' · '}{p.quantos}
                        </button>
                      ))}
                      {pendentes.length > 4 && (
                        <span style={{ fontSize: 13, color: 'rgba(26,23,20,0.5)',
                          alignSelf: 'center' }}>
                          e mais {pendentes.length - 4} planos
                        </span>
                      )}
                    </div>
                  </div>
                );
              })()}
              <PainelProfessor
                nomeProfessor={nomeProfessor}
                turmaId={turmaId}
                ucId={emCurso?.id}
                ucNome={emCurso?.nome}
                aulasHoje={planos.filter((p: any) => p.data === hojeISO).length}
                proximasAulas={planos.filter((p: any) => p.data > hojeISO).length}
                porValidar={(() => {
                  // Autoavaliações submetidas que ainda não têm validação.
                  const vals = new Set(getValidacoes().map((v: any) => v.selecaoId));
                  return getSelecoes().filter((s: any) =>
                    s.turmaId === turmaId && !vals.has(s.id)).length;
                })()}
                onAbrir={(v) => setVistaGlobal(v)}
                calendario={
                  <CalendarioMensal
                    planos={getPlanosAulaPorTurma(turmaId).filter((p: any) => p.estado !== 'arquivado')}
                    onAbrirPlano={(p: any) => setPlanoAberto(p)}
                    turmaId={turmaId}
                    onCriarNoDia={() => setVistaGlobal('planos')}
                    onPlanoEliminado={() => setRefreshKey(k => k + 1)}
                    key={'cal-' + refreshKey}
                  />
                }
              />
              </>
            );
          })()}
          {vistaGlobal === 'planos' && (
            <PlanoAula key={refreshKey} turmaId={turmaId} nomeProfessor={nomeProfessor}
              onAlteracao={registarAlteracao}
              onGuardado={(p?: TPlanoAula) => {
                limparAlteracoes();
                // O plano acabou de ser gravado — abre logo, sem o aviso de
                // "perdes o que estás a preencher". Esse aviso aparecia porque
                // a limpeza ainda não tinha sido aplicada; o professor achava
                // que o plano não fora criado e carregava outra vez, e cada
                // clique criava um plano novo, igual ao anterior.
                if (p) { setPlanoAberto(p); setPlanoEmPausa(null); }
              }}
              planoIdInicial={planoIdAlvo || undefined}
              onPlanoIdInicialUsado={() => setPlanoIdAlvo(null)} />
          )}
            {vistaGlobal === 'ficha' && (
              <ProfessorView turmaId={turmaId} nomeProfessor={nomeProfessor}
                onAlteracao={registarAlteracao} onGuardado={limparAlteracoes} />
            )}
            {vistaGlobal === 'guia' && (
              <ProfessorView turmaId={turmaId} nomeProfessor={nomeProfessor}
                modoGuia={true} onAlteracao={registarAlteracao} onGuardado={limparAlteracoes} />
            )}
            {vistaGlobal === 'requisicao' && <Requisicao nomeProfessor={nomeProfessor} turmaId={turmaId} />}
            {/* Novos items do menu */}
            {vistaGlobal === 'orcamentos' && (
              <OrcamentosView turmaId={turmaId} nomeProfessor={nomeProfessor}
                onAlteracao={registarAlteracao} onGuardado={limparAlteracoes} />
            )}
            {vistaGlobal === 'historial' && (
              <HistorialView turmaId={turmaId}
                onIrPara={(v, planoId) => { if (planoId) setPlanoIdAlvo(planoId); setVistaGlobal(v); }} />
            )}
            {vistaGlobal === 'ajuda' && <ManualProfessor />}
            {vistaGlobal === 'validacao' && <ValidacaoView turmaId={turmaId} />}
            {vistaGlobal === 'manual' && <ManualCozinheiro modoProf={true} nomeProfessor={nomeProfessor} />}
            {vistaGlobal === 'manuais_aluno' && <ManuaisAluno nomeProfessor={nomeProfessor} />}
            {vistaGlobal === 'biblioteca' && (
              <ProfessorView turmaId={turmaId} nomeProfessor={nomeProfessor}
                onAlteracao={registarAlteracao} onGuardado={limparAlteracoes} />
            )}
            {vistaGlobal === 'avaliacao_uc' && <AvaliacaoPorUC turmaId={turmaId} />}
            {vistaGlobal === 'copia_seguranca' && <CopiaSegurancaView />}
            {vistaGlobal === 'gestao_recuperacoes' && <GestaoRecuperacoes turmaId={turmaId} nomeProfessor={nomeProfessor} />}
            {vistaGlobal === 'mapa_competencias' && <MapaCompetencias turmaId={turmaId} />}
            {vistaGlobal === 'eventos' && <EventosWizard turmaId={turmaId} nomeProfessor={nomeProfessor} />}
            {vistaGlobal === 'cronograma' && <CronogramaTab turmaId={turmaId} />}
            {/* Dicionário movido para o ecrã do aluno */}
          </>

        <div className="no-print">
          <CentroAvisos
            perfil="professor"
            onNavegar={(aviso) => {
              const tab = (aviso.contexto?.tabDestino as VistaProf) || 'planos';
              const planoId = aviso.contexto?.planoId;
              irPara(tab);
              if (planoId) setPlanoIdAlvo(planoId);
            }}
          />
        </div>
      </LayoutProfessor>
    );
  }

  // ── Aluno e Coordenadora ─────────────────────────────────────────────────
  return (
    <div className="app-shell">
      <div className="no-print">
        <Header perfil={perfil} onSair={sair} nomeProfessor={nomeProfessor} syncStatus={syncStatus} onAtualizar={atualizarDados} />
      </div>
      {perfil === 'aluno' && aluno && <AlunoView key={refreshKey} aluno={aluno} />}
      {perfil === 'coordenadora' && <CoordenadoraView />}
    </div>
  );
}


// ── Componente de Ajuda ────────────────────────────────────────
export default function App() {
  return (
    <ErrorBoundary>
      <AppInterno />
    </ErrorBoundary>
  );
}
